#!/bin/sh
export HOME=/home/app
exec /usr/bin/max_home_automation
